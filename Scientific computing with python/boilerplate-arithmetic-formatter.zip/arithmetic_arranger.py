def arithmetic_arranger(problems, calc=False):
  #check all the error types
  #if any, dont run the rest of the program and return error code

  #if more than 5 problems, return error
  if(len(problems) > 5):
    return "Error: Too many problems."
  
  for item in problems:
    operand = item.split(" ")[1]
    num1 = item.split(" ")[0]
    num2 = item.split(" ")[2]
    
    #only accept numbers with digits, otherwise error
    if(not(num1.isdigit() and num2.isdigit())):
      return "Error: Numbers must only contain digits"

    #only accept numbers under 4 digits, otherwise error
    if(int(num1) > 9999 or int(num2) > 9999):
      return "Error: Numbers cannot be more than four digits."

    #only accept addition and subtraction operands, otherwise error
    if(operand == "+" or operand == "-"):
      #correct operand type, do nothing
      continue
    else:
      return "Error: Operator must be '+' or '-'."

    
  
  #if no errors, run the actual program
    
  result = ""
  
  for item in problems:
    operand = item.split(" ")[1]
    num1 = item.split(" ")[0]
    num2 = item.split(" ")[2]
    dp_length = len(num1) if int(num1) > int(num2) else len(num2)
    
    result += item.split(" ")[0].rjust(dp_length+2)
    result += "    "
  result += "\n";

  for item in problems:
    operand = item.split(" ")[1]
    num1 = item.split(" ")[0]
    num2 = item.split(" ")[2]
    dp_length = len(num1) if int(num1) > int(num2) else len(num2)
    
    result += operand
    result += item.split(" ")[2].rjust(dp_length+1)
    result += "    "
  result += "\n"

  for item in problems:
    operand = item.split(" ")[1]
    num1 = item.split(" ")[0]
    num2 = item.split(" ")[2]
    dp_length = len(num1) if int(num1) > int(num2) else len(num2)
    
    result += "-"*(dp_length+2)
    result += "    "  
  result += "\n"

  if(calc):
    for item in problems:
      calculation = 0
      num1 = int(item.split(" ")[0])
      num2 = int(item.split(" ")[2])
      dp_length = len(str(num1)) if int(num1) > int(num2) else len(str(num2))
      
      if(item.split(" ")[1] == "+"):
        calculation = num1 + num2
      elif(item.split(" ")[1] == "-"):
        calculation = num1 - num2
        
      result += str(calculation).rjust(dp_length+2)
      result += "    "
  return result;
    